document.getElementById('join-now').addEventListener('click', function() {
  alert('Welcome to Money Gain! Sign up to start playing.');
});
